<?php
//SELECT PARA OBTENER MIS DATOS
include 'conexionPDOEXP2.php';
$sentencia = $conexion->query("SELECT * FROM datos;");
$express = $sentencia->fetchAll(PDO::FETCH_OBJ); //fetchAll(PDO::FETCH_OBJ); ES UN FORMATO DE OBJETO
//print_r($express);//Con print_r yo imprimo todos los valores que tengan una variable
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" 
     integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"><link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' 
    rel='stylesheet'>

     <link rel="stylesheet" href="registro.css">

    <title>Registro</title>
</head>

<body>

 <!-- As a heading BARRA DE ENCABEZADO--> 
 <nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-brand mb-2 h1">Express-Outsorcing</span>
  </div>
</nav>

    <form action="insertarPDOEXP2.php" method="POST" class="formulario">
       
       <h1>Registrate</h1>

       <div class="contenedor"> 

       <div class="input-contenedor">
           <i class="fas fa-asterisk icon"></i>
           <input type="text" placeholder="Tipo de Documento...">
       </div>

        <div class="input-contenedor">
           <i class="fas fa-user icon"></i>
           <input type="text" id="ced1" name="cedula" placeholder="N° Documento...">
       </div>

        <div class="input-contenedor">
           <i class="fas fa-user icon"></i>
           <input type="text" id="nom1" name="nombre" placeholder="Nombre completo...">
       </div>

        <div class="input-contenedor">
           <i class="fas fa-home icon"></i>
           <input type="text" id="dir1" name="direccion" placeholder="Ingresa tu direccion">
       </div>

       <div class="input-contenedor">
           <i class="fas fa-phone icon"></i>
           <input type="text" id="tel" name="telefono" placeholder="Ingresa tu Telefono...">
       </div>

       <div class="input-contenedor">
           <i class="fas fa-envelope icon"></i>
           <input type="text" placeholder="Escribe Correo electronico...">
       </div>

       <div class="input-contenedor">
           <i class="fas fa-key icon"></i>
           <input type="password" placeholder="Escribe una contraseña...">
       </div>
        <form action="EXPROsesion.php" method="">
       <input type="submit" value="Registrate" class="button">
       </form>
       <hr>
       <div class="text-center" class="creado-por">
				<a class="link" href="ExproInicio.php">volver</a>
			</div>
       <p>Al registrarte, aceptas nuestras Condiciones de uso y Política de privacidad.</p>
       <p>¿Yá tienes una cuenta ? <a class="link" href="EXPROsesion.php">Iniciar sesion</a></p>
       </div> 
    </form>
    <hr>
<br>

    <!--PIE DE PAGINA-->
<footer>        
            <div class="social-media">
                <a href="" class="social-media-icon">
                    <i class='bx bxl-facebook-square'></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxs-door-open' ></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxl-redux'></i>
                </a>
            </div>
                </div>    
                <h2 class="titulo-final">&copy; EXPRO-ORCING|  Express-outsorcing.</h2>                      
         </footer>

         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
         integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>