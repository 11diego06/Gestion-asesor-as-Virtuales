<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
     crossorigin="anonymous">
    
     <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' 
    rel='stylesheet'>
   
     <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Raleway:500,600&display=swap" rel="stylesheet">
    
    <!-- MATERIALIZE. CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    
    <!-- CSS Estilos -->
    <link rel="stylesheet" href="psicologia1.css">

    <title>Psicología-Express-outsorcing</title>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Express-outsorcing</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="EXPROinicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Servicios
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li><a class="dropdown-item" href="#">Consulta y asesoria</a></li>
            <li><a class="dropdown-item" href="#">online call</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Seguridad social</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Categorías
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li><a class="dropdown-item" href="EXPROproductosNaturales1.php">Productos naturales</a></li>
            <li><a class="dropdown-item" href="EXPROtecnologia1.php">Tecnología</a></li>
            <li><a class="dropdown-item" href="EXPROdeportes1.php">Deportes</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROregistro.php" tabindex="-1" aria-disabled="true">Registrate</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROsesion.php" tabindex="-1" aria-disabled="true">Login</a>
        </li>
      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Buscar..." aria-label="Search">
        <button class="btn btn-outline-light" type="submit">Buscar</button>
      </form>
    </div>
  </div>
</nav>
<!--Fin formulario-->

<header class="header">
<div class="contenedor head">
            <h1 class="titulo">...PSICOLOGÍA...</h1>
            <p class="copy">...La importancia de tu salud mental...</p>
        </div>
</header>
    <br>
    <br>

    <h1 class="titulog">¡Si lo tienes en la mente lo tienes en la mano!</h1>
  
    <section>
      <div >
        <img src="imagenes/imgpsicologia5.png" class="ttt" >
    </div>
<br>
<br>
<br>

    <p class="ppp">La psicología es un campo escencial en la humanidad , por tal motivo es una rama que tiene que evolucionar 
      a medida que van pasando los años.Es una nueva oportunidad de organizar tu mente , tus ideas y expresar todo
      aquello que te amarra y no te deja ser libre mentalmente.Todas las personas pueden expresarse y asi mismo generar
      consentimiento de sus actos , todo dirigido a profesionales capacitados,éticos y empáticos.Todo lo puedes encontrar 
      aquí en cualquier hora y momento.
    </p>

    </section>

    <h1 class="titulog">¿Como lo hacemos?</h1>

    <section>
      <div>
        <img src="imagenes/imgpsicologia3.png" class="aaa" >
    </div>
<br>
<br>
<br>

    <p class="ppp">Nosotros como organización asesoramos de una manera que las personas se encuentren asi mismos , es decir ,
      en este campo especialmente buscamos aliarnos a la ciencia mas trascendental y progresiva con el objetivo de darles una 
      posibilidad de cambio , solución , paz y sobre todo lbertad. Aquí puedes manejar y compartir todas tus experiencias,
    Express-Outsorcing tiene profesionales que te acompañaran ayudaran y tu seras el unico afortunado de experimentar esos resultados. </p>
    
    </section>

<!--INICIO CARRUCEL-->
<div class="container">
        <div class="row">
            <div class="col s12">
                <h1 class="center-align titulog">EN QUE QUIERES ASESORARTE HOY</h1>
               
                <div class="carousel center-align">
                    <div class="carousel-item">
                        <h2 class="subtitulo">Familia y relación</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">Procesos reconstructivos</p>
                        <img src="imagenes/imgpsicologia7.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">La superación personal</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">El pensamiento y la psique</p>
                        <img src="imagenes/imgpsicologia6.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">Bienestar social y empresarial</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">Recursos humanos , expresion en público. </p>
                        <img src="imagenes/imgpsicologia2.png" alt="">
                    </div>

                    <!-- <div class="carousel-item">
                        <h2 class="subtitulo">Donas</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">avellanas</p>
                        <img src="img/muffins-02.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">munfin</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">vainilla</p>
                        <img src="img/muffins-03.jpg" alt="">
                    </div> -->

                </div>
            </div>
        </div>
    </div>







    <!--PIE DE PAGINA-->
<footer>        
            <div class="social-media">
                <a href="" class="social-media-icon">
                    <i class='bx bxl-facebook-square'></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxs-door-open' ></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxl-redux'></i>
                </a>
            </div>
                </div>    
                <h2 class="titulo-final">&copy; EXPRO-ORCING|  Express-outsorcing.</h2>                      
         </footer>
          

 <!--MATERIALIZE JS JavaScript -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    
    <!-- JS Main -->
    <script src="carrucel.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" 
crossorigin="anonymous"></script>
</body>
</html>