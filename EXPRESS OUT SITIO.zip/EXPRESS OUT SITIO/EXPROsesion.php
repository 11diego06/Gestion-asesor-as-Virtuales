
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" 
     integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
     <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' 
    rel='stylesheet'>
   
     <link rel="stylesheet" href="sesion.css">

    <title>Iniciar sesion</title>
</head>

<body>

 <!-- As a heading BARRA DE ENCABEZADO--> 
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <span class="navbar-brand mb-2 h1">Express-Outsorcing</span>
  </div>
</nav>

    <form action="EXPROvalidacionSesion.php" method="POST" class="formulario">
       
       <h1>Iniciar Sesion</h1>

       <div class="contenedor"> 

       <div class="input-contenedor">
            <i class="fas fa-user icon"></i>
             <label for="inputState" class="form-label">Tipo de Documento :</label>

         <select id="inputState" class="form-select">
             <option selected>Cedula de Ciudadania</option>
             <option>Tarjeta de identidad</option>
             <option>Cedula de Extrangeria</option>
             <option>Contraseña primera vez</option>
             <option>Registro civil</option>
         </select>
        </div>
           

       <div class="input-contenedor">
           <i class="fas fa-envelope icon"></i>
           <input type="text" name="usuario" placeholder="Correo electronico">
       </div>

       <div class="input-contenedor">
           <i class="fas fa-key icon"></i>
           <input type="password" name="clave" placeholder="Contraseña ó cedula">
       </div>
    
       <input type="submit" value="Iniciar sesion" class="button">
       <hr>
       <div class="text-center" class="creado-por">
				<a class="link" href="ExproInicio.php">volver</a>
			</div>
       <!-- <p>Al registrarte, aceptas nuestras Condiciones de uso y Política de privacidad.</p> -->
       <p>¿No tienes una cuenta? <a class="link" href="EXPROregistro.php">Registrate</a></p>
       </div> 
    </form>
<hr>
<br>
    <!--PIE DE PAGINA-->
<footer>        
            <div class="social-media">
                <a href="" class="social-media-icon">
                    <i class='bx bxl-facebook-square'></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxs-door-open' ></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxl-redux'></i>
                </a>
            </div>
                </div>    
                <h2 class="titulo-final">&copy; EXPRO-ORCING|  Express-outsorcing.</h2>                      
         </footer>

         <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
         integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>