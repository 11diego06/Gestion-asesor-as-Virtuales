<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    
   <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' 
    rel='stylesheet'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- MATERIALIZE. CSS -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css"> -->
   <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Raleway:500,600&display=swap" rel="stylesheet">
  
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js"></script>

    <link rel="stylesheet" href="contactanos.css">

    <title>Contactanos-Express-outsorcing</title>

  </head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Express-outsorcing</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="EXPROinicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Categorias 
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="EXPROtecnologia1.php">Tecnología</a></li>
            <li><a class="dropdown-item" href="EXPROdeportes1.php">Deportes</a></li>
            <li><a class="dropdown-item" href="EXPROproductosNaturales1.php">Productos Naturales</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="EXPROpsicologia1.php">Psicología</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROregistro.php" tabindex="-1" aria-disabled="true">¡ Registrate !</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROsesion.php" tabindex="-1" aria-disabled="true">¡ Iniciar Sesion !</a>
        </li>
      </ul>
      
      <!--INICIO INPUT-->
      
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Buscar..." aria-label="Search">
        <button class="btn btn-outline-light" type="submit">Buscar...</button>
      </form>
      
       <!--FIN INPUT-->
    </div>
  </div>
</nav>
<hr>
<br>
<br>


    <!-- MULTIPLE COLLAPSE -->
<center> 
 <p>
  <a class="btn btn-primary" data-bs-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="true" aria-controls="multiCollapseExample1">Franquicias y Alianzas</a>
  <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#multiCollapseExample2" aria-expanded="true" aria-controls="multiCollapseExample2">CEO Inf</button>
  <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target=".multi-collapse" aria-expanded="true" aria-controls="multiCollapseExample1 multiCollapseExample2">Express-Outsourcing</button>
</p>
<div class="row">
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample1">
      <div class="card card-body">
        FUNPSA.
      </div>
    </div>
  </div>
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample2">
      <div class="card card-body">
       <P> Diego Alejandro Suesca Chavez CEO /
        Brayan Moises Patiño Cuenca SCRUM MASTER/
        Jhon Deibi Pulgarin Perez ADMIN 1/
        Jose Miguel Alvarez Fagua ADMIN 2.
        </P>
      </div>
    </div>
  </div>
</div>
</center> 

<!--PIE DE PAGINA-->
<footer class="contenedor">
			<div class="redes-sociales">
				<div class="contenedor-icono">
					<a href="https://icons.getbootstrap.com/" target="_blank" class="twitter">
                    <i class="fa fa-whatsapp"></i>
					</a>
				</div>
				<div class="contenedor-icono">
					<a href="https://icons.getbootstrap.com/" target="_blank" class="facebook">
                    <i class="fab fa-facebook-f"></i>
					</a>
				</div>
				<div class="contenedor-icono">
					<a href="https://icons.getbootstrap.com/" target="_blank" class="instagram">
                    <i class="fab fa-instagram"></i>
					</a>
				</div>
			</div>
			<div class="text-center" class="creado-por">
				<a href="ExproInicio.php" class="link">Express-Outsorcing</a>
			</div>
		</footer>

     
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>        
</body>
</html>