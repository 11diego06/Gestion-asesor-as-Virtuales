<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" 
    crossorigin="anonymous">
    
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' 
    rel='stylesheet'>

     <!-- Fonts -->
     <link href="https://fonts.googleapis.com/css?family=Dancing+Script|Raleway:500,600&display=swap" rel="stylesheet">
    
    <!-- MATERIALIZE. CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
  
   
    <link rel="stylesheet" href="productosN.css">


    <title>Productos-Naturales-Express-Outsorcing</title>

</head>
<body>
    
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Express-outsorcing</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="EXPROinicio.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarScrollingDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Servicios
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarScrollingDropdown">
            <li><a class="dropdown-item" href="#">Consulta y asesoria</a></li>
            <li><a class="dropdown-item" href="#">Productos , accesorios y alimentos</a></li>
            <li><a class="dropdown-item" href="#">Procedimientos y dietas</a></li>
            <li><a class="dropdown-item" href="#">Testimonios y opiniones</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">meditación , ejercicios relax</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Categorias 
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="EXPROdeportes1.php">Deportes</a></li>
            <li><a class="dropdown-item" href="EXPROtecnologia1.php">Tecnología</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="EXPROpsicologia1.php">Psicología</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROregistro.php" tabindex="-1" aria-disabled="true">Registrate</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="EXPROsesion.php" tabindex="-1" aria-disabled="true">Login</a>
        </li>
      </ul>
      
      <!--INICIO INPUT-->
      
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Buscar..." aria-label="Search">
        <button class="btn btn-outline-light" type="submit">Buscar...</button>
      </form>
      
       <!--FIN INPUT-->
    </div>
  </div>
</nav>

<header class="header">
<div class="contenedor head">
            <h1 class="titulo">...PRODUCTOS NATURALES...</h1>
            <p class="copy">...Tu mente y tu cuerpo necesitan el apoyo de lo natural...</p>
        </div>
</header>

<!-- INICIO HOJA PAT -->

<header class="tituloG">
        <!-- <h1 >Productos Naturales</h1> -->

        <!--INICIO CARRUCEL-->
<div class="container">
        <div class="row">
            <div class="col s12">
                <h1 class="center-align titulog">La naturaleza, el mejor proveedor de salud</h1>
               
                <div class="carousel center-align">
                    <div class="carousel-item">
                        <h2 class="subtitulo">Productos</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">Naturaleza y escencia</p>
                        <img src="imagenes/imgprodnat2.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">Meditación</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">boo hi han </p>
                        <img src="imagenes/imgprodnat4.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">Alimentación</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">Saludable,hierbas</p>
                        <img src="imagenes/imgprodnat3.jpg" alt="">
                    </div>

                    <!-- <div class="carousel-item">
                        <h2 class="subtitulo">Donas</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">avellanas</p>
                        <img src="img/muffins-02.jpg" alt="">
                    </div>

                    <div class="carousel-item">
                        <h2 class="subtitulo">munfin</h2>
                        <div class="linea-division"></div>  
                        <p class="sabor">vainilla</p>
                        <img src="img/muffins-03.jpg" alt="">
                    </div> -->

                </div>
            </div>
        </div>
    </div> 
</header>
 <br>
 <br>
 <br>
   <hr>
       <h2 class="center-align titulog">...Naturaleza y vitalidad...</h2>
 <br>
 <br>
 <br>
    <section class="seccion" >
            <h2 class="center-align titulog">Los productos naturales son vitalidad...</h2>
        <img src="imagenes/ProducNat2.jpg">
</section>
<article id="articulo1">   
    <p class="articulo">La naturaleza brinda frecuentemente utilidades enriquecidas de mucha vitalidad , por tal motivo aqui encontraras productos naturales para que puedas curar tus malestares de la manera mas rapida y eficiente. </p>

    <p>Contamos con los mejores productos naturistas provenientes de las más grandes proveedoras de los mismos.</p>

    <br> A su vez contamos con asesores de gran calidad que pueden instruirlo en el caso que necesite saber de cual es el mejor medicamiento, tratamiento y modo de uso por si lo considera necesario.  <br>
    
        <br><img  src="imagenes/naturaleza1.png" ></br>
</article>
    
<!-- FIN HOJA PAT -->








  <!--PIE DE PAGINA-->
  <footer>        
            <div class="social-media">
                <a href="" class="social-media-icon">
                    <i class='bx bxl-facebook-square'></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxs-door-open' ></i>
                </a>
                <a href="" class="social-media-icon">
                    <i class='bx bxl-redux'></i>
                </a>
            </div>
                </div>    
                <h2 class="titulo-final">&copy; EXPRO-ORCING | | Express-outsorcing.</h2>                      
         </footer>
          
       <!--MATERIALIZE JS JavaScript -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    
    <!-- JS Main -->
    <script src="carrucel.js"></script>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
 integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>