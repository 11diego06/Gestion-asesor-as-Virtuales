<?php 

include "model.php";

if (isset($_POST['update'])) {

    if (isset($_POST['edit_Nombre']) && isset($_POST['edit_Telefono']) && isset($_POST['edit_Direccion']) && isset($_POST['edit_ ced'])) {

        if (isset($_POST['edit_Nombre']) && isset($_POST['edit_Telefono']) && isset($_POST['edit_Direccion']) && !empty($_POST['edit_id'])) {
            
            $data['edit_ced'] = $_POST['edit_ced'];
            $data['edit_Nombre'] = $_POST['edit_Nombre'];
            $data['edit_Telefono'] = $_POST['edit_Telefono'];
            $data['edit_Direccion'] = $_POST['edit_Direccion'];
            $model = new Model();

            $update = $model->update($data);
            
           
        } else {
            echo "
            <script>alert('empty fields')</script>
            ";
        }
    }
}