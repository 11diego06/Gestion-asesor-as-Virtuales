<?php

include 'model.php';

$del_ced = $_POST['del_ced'];

$model = new Model();

$del = $model->del($del_ced);

?>