<?php

include_once 'conexion2.php';
$stmt = $dbh->prepare("INSERT INTO datos (cedula, nombre, direccion, telefono) VALUES (?, ?, ?, ?)");
//bind
$cedula=$_POST['cedula'];
$nombre =$_POST['nombre'] ;
$direccion =$_POST['direccion'] ;
$telefono=$_POST['telefono'];

$stmt->bindParam(1, $cedula);
$stmt->bindParam(2, $nombre);
$stmt->bindParam(3, $direccion);
$stmt->bindParam(4, $telefono);
// Excecute
$stmt->execute();
if($stmt == TRUE) echo "Datos Insertados correctamente";
else echo "Algo salió mal. Por favor verifique el error";
?>