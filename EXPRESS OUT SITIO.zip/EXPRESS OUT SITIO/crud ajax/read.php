<?php
include 'model.php';

$read_ced = $_POST['read_ced'];

$model = new Model();

$row = $model->read($read_ced);

if (!empty($row)) { ?>

    <p>Cedula - <?php echo $row['Cedula']; ?></p>

    <p>Nombre - <?php echo $row['Nombre']; ?></p>

    <p>Dirección - <?php echo $row['Direccion']; ?></p>

    <p>Teléfono - <?php echo $row['Telefono']; ?></p>

   
  <?php
}

    ?>