<?php
class Model
{
    private $server = "localhost";
    private $username = "root";
    private $password = "";
    private $db = "expressousorsing";
    private $conn;

    public function __construct()
    {
        try {
            $this->conn = new PDO(
                "mysql:host=$this->server;dbname=$this->db",
                $this->username,
                $this->password
            );
        } catch (PDOException $e) {
            echo "conexion fallida" . $e->getMessage();
        }
    }

    public function insert()
    {
        if (isset($_POST['submit'])) {

            if (isset($_POST['Cedula']) && isset($_POST['Nombre']) && isset($_POST['Telefono']) && isset($_POST['Direccion'])) {

                if (!empty($_POST['Cedula']) && !empty($_POST['Nombre']) && !empty($_POST['Telefono']) && !empty($_POST['Direccion'])) {
                    $ced=$_POST['Cedula'];
                    $nom=$_POST['Nombre'];
                    $tel=$_POST['Telefono'];
                    $dir=$_POST['Direccion'];                    

                    $query = "INSERT INTO registro_de_usuarios ( Cedula, Nombre, Telefono, Direccion) VALUES ('$ced','$nom','$tel','$dir')";
                    if ($sql = $this->conn->exec($query)) {
                        echo '
                       <div class="alert alert-success alert-dismissible fade show" role="alert">
                       Tarea Agregada con exito
                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                       </button>
                     </div>
                       ';
                    } else {
                        echo '
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                       Error en Agregar la Tarea
                       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                         <span aria-hidden="true">&times;</span>
                       </button>
                     </div>
                        ';
                    }
                } else {
                    echo '<script>
                     var sum="*No deben estar vacios";
                    document.getElementById("Cedula").style.border="1px solid red";
                    document.getElementById("emailHelp").style.color="red";
                    document.getElementById("emailHelp").innerHTML = sum
                    document.getElementById("emailHelp1").style.color="red";
                    document.getElementById("emailHelp1").innerHTML = sum;;
                    document.getElementById("Nombre").style.border="1px solid red";
                    document.getElementById("Telefono").style.border="1px solid red";
                    document.getElementById("emailHelp2").style.color="red";
                    document.getElementById("emailHelp2").innerHTML = sum
                    document.getElementById("emailHelp3").style.color="red";
                    document.getElementById("emailHelp3").innerHTML = sum;;
                    document.getElementById("Direccion").style.border="1px solid red";
                        </script>';
                }
            }
        }
    }

    public function fetch(){
        $data = null;
        $stmt = $this->conn->prepare("SELECT * FROM registro_de_usuarios");
        $stmt->execute();
        $data = $stmt->fetchAll();

        return $data;
    }

    public function del($del_ced){
        $query = "DELETE FROM registro_de_usuarios WHERE Cedula = '$del_ced' ";
        if ($sql = $this->conn->exec($query)) {
            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
            Tarea Eliminada
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }else {
            echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
            not delete
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>';
        }
    }

    public function read($read_ced){
      $data = null;

      $stmt = $this->conn->prepare("SELECT * FROM registro_de_usuarios WHERE Cedula ='$read_ced' ");

      $stmt->execute();

      $data = $stmt->fetch();

      return $data;
    }

    public function edit($edit_ced){
      $data = null;

      $stmt = $this->conn->prepare("SELECT * FROM  registro_de_usuarios WHERE Cedula ='$edit_ced'");

      $stmt->execute();

      $data = $stmt->fetch();

      return $data;
    }

    public function update($data){
      $query = "UPDATE registro_de_usuarios SET Cedula = '$data[edit_ced]', Nombre = '$data[edit_Nombre]', Telefono = '$data[edit_Telefono]', Direccion = '$data[edit_Direccion]'
      WHERE Cedula='$data[edit_ced]'";

      if ($sql = $this->conn->exec($query)) {
        echo '
        <div class="alert alert-success alert-dismissible fade show" role="alert">
        Record update successfully
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <script>$("#exampleModal1").modal("hide")<script>
        ';
      }else {
        echo '
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
        Failed to update
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        ';
      }
    }
}
