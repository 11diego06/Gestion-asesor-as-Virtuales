<?php

include 'model.php';

$model  = new Model();

$insert = $model->insert();

?>