<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <title>Formulario Registro</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12 mt-5">
        <h1 class="text-center">Formulario de Registro</h1>
        <hr style="height: 1px; color: black; background-color: black;">
      </div>
    </div>
    <div class="row">
      <div class="col-md-5 mx-auto">
        <form id="form" action="post">
          <div id="result"></div>
          <div class="form-group">
            <label for="">Cédula</label>
            <input type="text" id="Cedula" class="form-control">
            <div id="emailHelp" class="form-text" style="color:grey; font-size:15px;"></div>
          </div>
          <div class="form-group">
            <label for="">Nombre</label>
            <textarea name="Nombre" id="Nombre" cols="" rows="1" class="form-control"></textarea>
            <div id="emailHelp1" class="form-text" style="color:grey; font-size:15px;"></div>
          </div>
          <div class="form-group">
            <label for="">Dirección</label>
            <textarea name="Direccion" id="Direccion" cols="" rows="1" class="form-control"></textarea>
            <div id="emailHelp2" class="form-text" style="color:grey; font-size:15px;"></div>
          </div>
          <div class="form-group">
            <label for="">Teléfono</label>
            <textarea name="Telefono" id="Telefono" cols="" rows="1" class="form-control"></textarea>
            <div id="emailHelp3" class="form-text" style="color:grey; font-size:15px;"></div>
          </div>
          <div class="form-group">
            <button type="submit" id="submit" class="btn btn-outline-success">Guardar</button>
          </div>
          <div class="form-group">
              <button type="reset" class="btn btn-danger" onclick="borrar()">Limpiar</button>
          </div>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12 mt-1">
        <div id="show"></div>
        <div id="fetch"></div>
      </div>
    </div>
  </div>
  <script>
    function borrar(){
      var sum=" ";
        document.getElementById("emailHelp1").style.color='grey';
        document.getElementById("emailHelp2").style.color='grey';
        document.getElementById("emailHelp3").style.color='grey';
        document.getElementById("emailHelp1").style.color='grey';
        document.getElementById("Nombre").style.border='1px solid grey';
        document.getElementById("Cedula").style.border='1px solid grey';
        document.getElementById("Telefono").style.border='1px solid grey';
        document.getElementById("Direccion").style.border='1px solid grey';
        document.getElementById("emailHelp").style.color='grey';
        document.getElementById("emailHelp").innerHTML = sum;
        document.getElementById("emailHelp1").innerHTML = sum;
        document.getElementById("emailHelp2").innerHTML = sum;
        document.getElementById("emailHelp3").innerHTML = sum;
        document.getElementById("emailHelp").style.color='grey';
       
        
    }
  </script>

  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Datos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="read_data"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Cerrar</button>
         
        </div>
      </div>
    </div>
  </div>


  <!-- Editar Modal -->
  <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Editar Datos</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div id="edit_data"></div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          <button type="button" class="btn btn-outline-success" id="update">Modificar</button>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
  <script>
    $(document).on("click", "#submit", function(e) {
      e.preventDefault();
      var Cedula = $("#Cedula").val();
      var Nombre = $("#Nombre").val();
      var Telefono = $("#Telefono").val();
      var Direccion = $("#Direccion").val();
      var submit = $("#submit").val();

      $.ajax({
        url: "insert.php",
        type: "post",
        data: {
          Cedula: Cedula,
          Nombre: Nombre,
          Telefono: Telefono,
          Direccion: Direccion,
          submit: submit
        },
        success: function(data) {
          fetch();
          $("#result").html(data);
        }
      })

      $("#form")[0].reset();
    });

    //Fetch records

    function fetch() {
      $.ajax({
        url: "fetch.php",
        type: "post",
        success: function(data) {
          $("#fetch").html(data);
        }
      });
    }
    fetch();

    //Delete

    $(document).on("click", "#del", function(e) {
      e.preventDefault();

      if (window.confirm("¿Esta seguro de borrarlo?")) {
        var del_ced = $(this).attr("value");

        $.ajax({
          url: "del.php",
          type: "post",
          data: {
            del_ced: del_ced
          },
          success: function(data) {
            fetch();
            $("#show").html(data);
          }
        });
      } else {
        return false;
      }

    });

    //leer datos

    $(document).on("click", "#read", function(e) {
      e.preventDefault();

      var read_ced = $(this).attr("value");

      $.ajax({
        url: "read.php",
        type: "post",
        data: {
          read_ced: read_ced
        },
        success: function(data) {
          $("#read_data").html(data);
        }
      })
    });

    //Editar
    $(document).on("click", "#edit", function(e) {
      e.preventDefault();
      if (window.confirm("¿Esta seguro de editarlo?")){
        var edit_ced = $(this).attr("value");

          $.ajax({
            url: "edit.php",
            type: "post",
            data: {
              edit_ced: edit_ced
            },

            success: function(data) {
              $("#edit_data").html(data);
            }
          });
      }
     
    });

    //update

    $(document).on("click", "#update", function(e){
      e.preventDefault();

      var edit_Nombre = $("#edit_Nombre").val();
      var edit_Telefono = $("#edit_Telefono").val();
      var edit_Direccion= $("#edit_Direccion").val();
      var update = $("#update").val();
      var edit_ced = $("#edit_id").val();
      

      $.ajax({
        url: "update.php",
        type: "post",
        data:{
          edit_ced:edit_ced,
          edit_Nombre:edit_Nombre,
          edit_Telefono:edit_Telefono,
          edit_Direccion:edit_Direccion,
          
          update:update
        },
        success: function(data){
          fetch();
          $("#show").html(data);
        }
      });
    });
  </script>
</body>

</html>