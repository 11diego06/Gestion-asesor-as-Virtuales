<?php

include 'model.php';

$edit_ced = $_POST['edit_ced'];

$model = new Model();

$row = $model->edit($edit_ced);

if (!empty($row)) { ?>

    <form id="form" action="post">
        <div>
            <input type="hidden" id="edit_ced" value="<?php echo $row['Cedula'] ?>">
        </div>
        <div class="form-group">
            <label for="">Cédula</label>
            <input type="text" id="edit_ced" class="form-control" value="<?php echo $row['Cedula']; ?>">
        </div>
        <div class="form-group">
            <label for="">Nombre</label>
            <textarea name="Nombre" id="edit_Nombre" cols="" rows="1" class="form-control" ><?php echo $row['Nombre']; ?></textarea>
        </div>
        <div class="form-group">
            <label for="">Teléfono</label>
            <textarea name="Telefono" id="edit_Telefono" cols="" rows="1" class="form-control" ><?php echo $row['Telefono']; ?></textarea>
        </div>
        <div class="form-group">
            <label for="">Dirección</label>
            <textarea name="Direccion" id="edit_Direccion" cols="" rows="1" class="form-control" ><?php echo $row['Direccion']; ?></textarea>
        </div>
    </form>

<?php

}

?>