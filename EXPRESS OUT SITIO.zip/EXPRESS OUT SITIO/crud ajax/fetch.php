<?php
include 'model.php';

$model = new Model();

$rows = $model->fetch();
?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Cédula</th>
            <th>Nombre</th>
            <th>Dirección</th>
            <th>Teléfono</th>
            <th>Opciones</th>
        </tr>
    </thead>
    <tbody>
        <?php

$i = 1;
        if (!empty($rows)) {
            foreach ($rows as $row) { ?>

                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['Cedula']; ?></td>
                    <td><?php echo $row['Nombre']; ?></td>
                    <td><?php echo $row['Direccion']; ?></td>
                    <td><?php echo $row['Telefono']; ?></td>
                    <td>
                        <a href="" id="read" class="btn btn-outline-success" value="<?php echo $row['Cedula'] ?> " data-toggle="modal" data-target="#exampleModal">Leer</a>
                        <a href="" id="del" class="btn btn-outline-danger" value="<?php echo $row['Cedula'] ?>">Eliminar</a>
                        <a href="" id="edit" class="btn btn-outline-warning" value="<?php echo $row['Cedula'] ?>" data-toggle="modal" data-target="#exampleModal1">Editar</a>
                    </td>
                </tr>

        <?php
            }
        } 
        ?>
    </tbody>
</table>